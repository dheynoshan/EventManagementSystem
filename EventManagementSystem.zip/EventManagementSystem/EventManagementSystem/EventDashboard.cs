﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EventManagementSystem
{
    public partial class EventDashboard : Form
    {
        public EventDashboard()
        {
            InitializeComponent();
            Event ev = new Event();
            viewEvents.DataSource = ev.ShowEvents();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void viewEvents_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            using (EventUpdate eveUp = new EventUpdate())
            {
                eveUp.EventID.Text = this.viewEvents.CurrentRow.Cells[0].Value.ToString();
                eveUp.Name1.Text = this.viewEvents.CurrentRow.Cells[1].Value.ToString();
                //eveUp.Date.Text = Convert.ToDateTime(this.viewEvents.CurrentRow.Cells[2].Value.ToString());
                //eveUp.Time.Text = this.viewEvents.CurrentRow.Cells[3].Value.ToString();
                eveUp.Category.Text = this.viewEvents.CurrentRow.Cells[4].Value.ToString();
                eveUp.Organizer.Text = this.viewEvents.CurrentRow.Cells[5].Value.ToString();
                eveUp.Description.Text = this.viewEvents.CurrentRow.Cells[6].Value.ToString();
                eveUp.Price.Text = this.viewEvents.CurrentRow.Cells[7].Value.ToString();
                eveUp.ShowDialog();

                Event ev = new Event();
                viewEvents.DataSource = ev.ShowEvents();
            }
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            using(EventRegister eveReg = new EventRegister())
            {
                eveReg.ShowDialog();
                Event ev = new Event();
                viewEvents.DataSource = ev.ShowEvents();
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (EventUpdate eveUp = new EventUpdate())
            {
                eveUp.ShowDialog();
                Event ev = new Event();
                viewEvents.DataSource = ev.ShowEvents();
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Event ev = new Event();
            viewEvents.DataSource = ev.ShowEvents();
        }

        private void EventDashboard_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            using(Booking book = new Booking())
            {
                this.Dispose();
                book.ShowDialog();
                BookingClass ev = new BookingClass();
                viewEvents.DataSource = ev.ShowBookings();
                
            }
        }
    }
}
