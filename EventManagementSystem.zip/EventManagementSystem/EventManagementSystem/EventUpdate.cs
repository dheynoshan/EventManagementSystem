﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EventManagementSystem
{
    public partial class EventUpdate : Form
    {
        public EventUpdate()
        {
            InitializeComponent();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Event ev = new Event();
            DataTable daTab = ev.SearchEvent(Convert.ToInt32(eventID.Text));
            name.Text = (string)daTab.Rows[0][1];
            date.Text = (string)daTab.Rows[0][2];
            time.Text = (string)daTab.Rows[0][3];
            category.Text = (string)daTab.Rows[0][4];
            organizer.Text = (string)daTab.Rows[0][5];
            description.Text = (string)daTab.Rows[0][6];
            price.Text = (string)daTab.Rows[0][7];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Event ev = new Event(Convert.ToInt32(eventID.Text), name.Text, date.Text, time.Text, category.Text, organizer.Text, description.Text, Convert.ToInt32(price.Text));
                ev.ModifyEvent();
                this.Dispose();
            }
            catch
            {
                MessageBox.Show("Invalid Arguments", "Error");
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                Event ev = new Event(Convert.ToInt32(eventID.Text));
                ev.RemoveEvent();
                this.Dispose();
            }
            catch
            {
                MessageBox.Show("Invalid Arguments", "Error");
            }
            
        }

        private void eventID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
