﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EventManagementSystem
{
    public partial class Booking : Form
    {
        public Booking()
        {
            InitializeComponent();
            BookingClass ev = new BookingClass();
            bookingView.DataSource = ev.ShowBookings();
        }

        private void Booking_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                BookingClass ev = new BookingClass(Convert.ToInt32(eventID.Text));
                ev.AddBooking();
                bookingView.DataSource = ev.ShowBookings();
            }
            catch {
                MessageBox.Show("Invalid Arguments","Error");
            };
         }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                BookingClass ev = new BookingClass();
                ev.BookingID = Convert.ToInt32(bookingID.Text);
                ev.RemoveBooking();
                bookingView.DataSource = ev.ShowBookings();
            }
            catch 
            {
                MessageBox.Show("Invalid Arguments", "Error");
            };
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            using (EventDashboard eveDas = new EventDashboard())
            {
                this.Dispose();
                eveDas.ShowDialog();
                //BookingClass ev = new BookingClass();
                //viewEvents.DataSource = ev.ShowBookings();

            }
            
        }
    }
}
