﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace EventManagementSystem
{
    class BookingClass
    {
        int bookingID;
        string bookingDate;
        int userID;
        int eventID;

        public int BookingID
        {
            get { return bookingID; }
            set { bookingID = value; }
        }
        public string BookingDate
        {
            get { return bookingDate; }
            set { bookingDate = value; }
        }
        public int UserID
        {
            get { return userID; }
            set { userID = value; }
        }
        public int EventID
        {
            get { return eventID; }
            set { eventID = value; }
        }

        public BookingClass()
        {
        }

        public BookingClass(int eventID)
        {
            this.eventID = eventID;
        }

        //public BookingClass(int bookingID)
        //{
        //    this.bookingID = bookingID;
        //}
        public BookingClass(int bookingID, string bookingDate, int userID, int eventID)
        {
            this.bookingID = bookingID;
            this.bookingDate = bookingDate;
            this.userID = userID;
            this.eventID = eventID;
        }
        public BookingClass(int bookingID, int eventID)
        {
            this.bookingID = bookingID;
            this.eventID = eventID;
        }

        public void AddBooking()
        {
            DBConnection dbCon = new DBConnection();
            dbCon.InsertBooking(eventID);
        }

        public void RemoveBooking()
        {
            DBConnection dbCon = new DBConnection();
            dbCon.DeleteBooking(bookingID);
        }

        public DataTable ShowBookings()
        {
            DBConnection dbCon = new DBConnection();
            return dbCon.RetrieveBookings();
        }

        //public DataTable SearchEvent(int eventID)
        //{
        //    DBConnection dbCon = new DBConnection();
        //    return dbCon.SelectOneEvent(eventID);
        //}

        public void ModifyBooking()
        {
            DBConnection dbCon = new DBConnection();
            //dbCon.UpdateEvents(bookingID, eventID);
        }
    }
}
