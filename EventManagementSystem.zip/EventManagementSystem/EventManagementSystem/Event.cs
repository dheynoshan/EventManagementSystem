﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Oracle.DataAccess.Client;

namespace EventManagementSystem
{
    /// <summary>
    /// Provides the functionality for events
    /// </summary>
    class Event
    {
        /// <summary>
        /// Variable Declaration
        /// </summary>
        int eventID;
        string eventName;
        string eventDate;
        string eventTime;
        string eventCategory;
        string eventOrganizer;
        string eventDescription;
        int ticketPrice;

        /// <summary>
        /// Getters and Setters
        /// </summary>
        public int EventID
        {
            get { return eventID; }
            set { eventID = value; }
        }
        public string EventName
        {
            get { return eventName; }
            set { eventName = value; }
        }
        public string EventDate
        {
            get { return eventDate; }
            set { eventDate = value; }
        }
        public string EventTime
        {
            get { return eventTime; }
            set { eventTime = value; }
        }
        public string EventCategory
        {
            get { return eventCategory; }
            set { eventCategory = value; }
        }
        public string EventOrganizer
        {
            get { return eventOrganizer; }
            set { eventOrganizer = value; }
        }
        public string EventDescription
        {
            get { return eventDescription; }
            set { eventDescription = value; }
        }
        public int TicketPrice
        {
            get { return ticketPrice; }
            set { ticketPrice = value; }
        }

        /// <summary>
        /// Constructors
        /// </summary>
        public Event()
        {
        }

        public Event(int eventID)
        {
            this.eventID = eventID;
        }

        public Event(string eventName, string eventDate, string eventTime, string eventCategory,
            string eventOrganizer, string eventDescription, int ticketPrice)
        {
            this.eventName = eventName;
            this.eventDate = eventDate;
            this.eventTime = eventTime;
            this.eventCategory = eventCategory;
            this.eventOrganizer = eventOrganizer;
            this.eventDescription = eventDescription;
            this.ticketPrice = ticketPrice;
        }

        public Event(int eventID, string eventName, string eventDate, string eventTime, string eventCategory,
            string eventOrganizer, string eventDescription, int ticketPrice)
        {
            this.eventID = eventID;
            this.eventName = eventName;
            this.eventDate = eventDate;
            this.eventTime = eventTime;
            this.eventCategory = eventCategory;
            this.eventOrganizer = eventOrganizer;
            this.eventDescription = eventDescription;
            this.ticketPrice = ticketPrice;
        }

       
        /// <summary>
        /// Adding Events
        /// </summary>
        /// <param name =></param>
        /// <returns></returns>
        public void AddEvent()
        {
            DBConnection dbCon = new DBConnection();
            dbCon.InsertEvent(eventName, eventDate, eventTime, eventCategory, eventOrganizer, eventDescription, ticketPrice);
        }

        /// <summary>
        ///  Remove Events
        /// </summary>
        /// <param name =></param>
        /// <returns></returns>
        public void RemoveEvent()
        {
            DBConnection dbCon = new DBConnection();
            dbCon.DeleteEvent(eventID);
        }

        /// <summary>
        /// Displays the events from DB
        /// </summary>
        /// <param name =></param>
        /// <returns>Data table of the events</returns>
        public DataTable ShowEvents()
        {
            DBConnection dbCon = new DBConnection();
            return dbCon.RetrieveEvents();
        }

        public DataTable SearchEvent(int eventID)
        {
            DBConnection dbCon = new DBConnection();
            return dbCon.SelectOneEvent(eventID);
        }

        /// <summary>
        /// Update Events
        /// </summary>
        /// <param name =></param>
        /// <returns></returns>
        public void ModifyEvent()
        {
            DBConnection dbCon = new DBConnection();
            dbCon.UpdateEvents(eventID, eventName, eventDate, eventTime, eventCategory,
            eventOrganizer, eventDescription, ticketPrice);
        }

    }
}
