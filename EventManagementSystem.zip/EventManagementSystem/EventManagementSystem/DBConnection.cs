﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Data;
//using System.Data.DataTable;
using System.Globalization;


namespace EventManagementSystem
{
    class DBConnection
    {
        private OracleConnection conn = new OracleConnection("Data Source=DLK1TRNDEV806/MATRIX; User ID=ifsapp; Password=ifsapp");

        #region LoginTest
        public void VerifyLogin(string userName, string password)
        {
            string verifyFunction = "User_Verify_Naddlk";
            OracleCommand cmd = new OracleCommand(verifyFunction, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("user_name", OracleDbType.Varchar2, userName, ParameterDirection.Input);
            cmd.Parameters.Add("login_password", OracleDbType.Varchar2, password, ParameterDirection.Input);
            //-----------------------------------------------------------------------------------
            //cmd.Parameters.Add("", OracleDbType.Varchar2, ParameterDirection.ReturnValue);
            //OracleDataAdapter adapter = new OracleDataAdapter(verifyFunction, conn);
            //adapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            //adapter.SelectCommand.Parameters.Add("user_name", OracleDbType.Varchar2).Value = userName;
            //adapter.SelectCommand.Parameters.Add("login_password", OracleDbType.Date).Value = Password;
            //-------------------------------------------------------------------
            try
            {
                conn.Open();
                //OracleTransaction trans = conn.BeginTransaction();
                int returnValue = cmd.ExecuteNonQuery();
                //int exec = adapter.SelectCommand.ExecuteNonQuery();
                //trans.Commit();

                System.Windows.Forms.MessageBox.Show(returnValue.ToString(), "Sucess");
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("DB Issue");
            }
            finally
            {
                conn.Close();
            }

        }
        #endregion LoginTest

        #region EventDataTable
        public DataTable CreateEventTable()
        {
            DataTable table = new DataTable();
            table.Columns.Add("Event Id", typeof(Int32));
            table.Columns.Add("Event Name", typeof(string));
            table.Columns.Add("Date", typeof(string));
            table.Columns.Add("Time", typeof(string));
            table.Columns.Add("Category", typeof(string));
            table.Columns.Add("Organizer", typeof(string));
            table.Columns.Add("Description", typeof(string));
            table.Columns.Add("Ticket Price", typeof(Int32));

            return table;
        }
        #endregion EventDataTable
        
        #region RetrieveEvent
        public DataTable RetrieveEvents()
        {
            conn.Open();
            string retrieveProcedure = "Event_Naddlk_API.Retrieve_Event_Naddlk";
            OracleCommand cmd = new OracleCommand(retrieveProcedure, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            List<Event> eventList = new List<Event>();
            OracleParameter output = cmd.Parameters.Add("event_cursor_", OracleDbType.RefCursor);
            output.Direction = ParameterDirection.Output;
            cmd.ExecuteNonQuery();

            OracleDataReader reader = ((OracleRefCursor)output.Value).GetDataReader();
            while (reader.Read())
            {
                Event eve = new Event();

                eve.EventID = reader.GetInt32(0);
                eve.EventName = reader.GetString(1);
                eve.EventDate = reader.GetDateTime(2).ToString();
                eve.EventTime = reader.GetString(3);
                eve.EventCategory = reader.GetString(4);
                eve.EventOrganizer = reader.GetString(5);
                eve.EventDescription = reader.GetString(6);
                eve.TicketPrice = reader.GetInt32(7);


                eventList.Add(eve);
            }
            conn.Close();

            DataTable dTabEve = new DataTable();
            dTabEve = CreateEventTable();

            foreach (Event ev in eventList)
            {
                dTabEve.Rows.Add(ev.EventID, ev.EventName, ev.EventDate,
                    ev.EventTime, ev.EventCategory, ev.EventOrganizer, ev.EventDescription, ev.TicketPrice); // 
            }
            return dTabEve;
            

        }

        #endregion RetrieveEvent
        
        #region InsertEvent
        public void InsertEvent(string eventName, string eventDate, string eventTime, string eventCategory, string eventOrganizer, string eventDescription, int ticketPrice)
        {
            DateTime eventDateConv = DateTime.Parse(eventDate, new CultureInfo("en-CA"));
            string insertProcedure = "Event_Naddlk_API.Insert_Event_Naddlk";
            
            OracleDataAdapter adapter = new OracleDataAdapter(insertProcedure, conn);
            adapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            adapter.SelectCommand.Parameters.Add("event_name", OracleDbType.Varchar2).Value = eventName;
            adapter.SelectCommand.Parameters.Add("event_date", OracleDbType.Date).Value = eventDateConv;
            adapter.SelectCommand.Parameters.Add("event_time", OracleDbType.Varchar2).Value = eventTime;
            adapter.SelectCommand.Parameters.Add("event_category", OracleDbType.Varchar2).Value = eventCategory;
            adapter.SelectCommand.Parameters.Add("event_organizer", OracleDbType.Varchar2).Value = eventOrganizer;
            adapter.SelectCommand.Parameters.Add("event_description", OracleDbType.Varchar2).Value = eventDescription;
            adapter.SelectCommand.Parameters.Add("ticket_price", OracleDbType.Int32).Value = ticketPrice;
            //OracleCommand command = new OracleCommand(insertProcedure, conn);

            try
            {
                conn.Open();
                //OracleTransaction trans = conn.BeginTransaction();
                int exec = adapter.SelectCommand.ExecuteNonQuery();
                //trans.Commit();
                
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("DB Issue");
            }
            finally
            {
                conn.Close();
                System.Windows.Forms.MessageBox.Show("Event is added", "Success");
            }
        }
        #endregion InsertEvent

        #region UpdateEvents
        public void UpdateEvents(int eventID, string eventName, string eventDate, string eventTime, string eventCategory, string eventOrganizer, string eventDescription, int ticketPrice)
        {

            DateTime eventDateConv = DateTime.Parse(eventDate, new CultureInfo("en-CA"));
            string updateProcedure = "Event_Naddlk_API.Update_Event_Naddlk";

            OracleDataAdapter adapter = new OracleDataAdapter(updateProcedure, conn);
            adapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            adapter.SelectCommand.Parameters.Add("event_id", OracleDbType.Int32).Value = eventID;
            adapter.SelectCommand.Parameters.Add("event_name", OracleDbType.Varchar2).Value = eventName;
            adapter.SelectCommand.Parameters.Add("event_date", OracleDbType.Date).Value = eventDateConv;
            adapter.SelectCommand.Parameters.Add("event_time", OracleDbType.Varchar2).Value = eventTime;
            adapter.SelectCommand.Parameters.Add("event_category", OracleDbType.Varchar2).Value = eventCategory;
            adapter.SelectCommand.Parameters.Add("event_organizer", OracleDbType.Varchar2).Value = eventOrganizer;
            adapter.SelectCommand.Parameters.Add("event_description", OracleDbType.Varchar2).Value = eventDescription;
            adapter.SelectCommand.Parameters.Add("ticket_price", OracleDbType.Int32).Value = ticketPrice;
            //OracleCommand command = new OracleCommand(updateProcedure, conn);

            try
            {
                conn.Open();
                //OracleTransaction trans = conn.BeginTransaction();
                int exec = adapter.SelectCommand.ExecuteNonQuery();
                //trans.Commit();
                
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("DB update Issue");
            }
            finally
            {
                conn.Close();
                System.Windows.Forms.MessageBox.Show("Event is Updated", "Sucess");
            }

        }

        #endregion UpdateEvent

        #region DeleteEvent
        public void DeleteEvent(int eventID)
        {

            string deleteProcedure = "Event_Naddlk_API.Delete_Event_Naddlk";
            OracleDataAdapter adapter = new OracleDataAdapter(deleteProcedure, conn);
            adapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            adapter.SelectCommand.Parameters.Add("event_id", OracleDbType.Int32).Value = eventID;

            try
            {
                conn.Open();
                //OracleTransaction trans = conn.BeginTransaction();
                int exec = adapter.SelectCommand.ExecuteNonQuery();
                //trans.Commit();
                
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("DB Issue");
            }
            finally
            {
                conn.Close();
                System.Windows.Forms.MessageBox.Show("Event is Deleted", "Sucess");
            }

        }

        #endregion DeleteEvent

        #region SelectAnEvent
        public DataTable SelectOneEvent(int eventID)
        {
            conn.Open();
            string retrieveProcedure = "Select_An_Event_Naddlk";
            OracleCommand cmd = new OracleCommand(retrieveProcedure, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            //Event eve = new Event();
            List<Event> eventList = new List<Event>();
            OracleParameter input = cmd.Parameters.Add("event_id_", OracleDbType.Int32);
            input.Direction = ParameterDirection.Input;
            OracleParameter output = cmd.Parameters.Add("event_cursor_", OracleDbType.RefCursor);
            output.Direction = ParameterDirection.Output;
            cmd.ExecuteNonQuery();

            OracleDataReader reader = ((OracleRefCursor)output.Value).GetDataReader();
            while (reader.Read())
            {
                Event eve = new Event();

                eve.EventID = reader.GetInt32(0);
                eve.EventName = reader.GetString(1);
                eve.EventDate = reader.GetDateTime(2).ToString();
                eve.EventTime = reader.GetString(3);
                eve.EventCategory = reader.GetString(4);
                eve.EventOrganizer = reader.GetString(5);
                eve.EventDescription = reader.GetString(6);
                eve.TicketPrice = reader.GetInt32(7);

            }
            conn.Close();
            DataTable dTabEve = new DataTable();
            dTabEve = CreateEventTable();

            foreach (Event ev in eventList)
            {
                dTabEve.Rows.Add(ev.EventID, ev.EventName, ev.EventDate,
                    ev.EventTime, ev.EventCategory, ev.EventOrganizer, ev.EventDescription, ev.TicketPrice); // 
                //dTabEve.Rows.Add(eve.EventID, eve.EventName, eve.EventDate,
                //    eve.EventTime, eve.EventCategory, eve.EventOrganizer, eve.EventDescription, eve.TicketPrice);
            }
            return dTabEve;
        }

        #endregion SelectAnEvent

        //=============================================================================================

        #region BookingDataTable
        public DataTable CreateBookingTable()
        {
            DataTable table = new DataTable();
            table.Columns.Add("Booking ID", typeof(Int32));
            table.Columns.Add("Booking Date", typeof(string));
            table.Columns.Add("User ID", typeof(Int32));
            table.Columns.Add("Event ID", typeof(Int32));

            return table;
        }
        #endregion BookingDataTable
        
        #region RetrieveBooking
        public DataTable RetrieveBookings()
        {
            conn.Open();
            string retrieveProcedure = "Booking_Naddlk_API.Retrieve_Booking_Naddlk";
            OracleCommand cmd = new OracleCommand(retrieveProcedure, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            List<BookingClass> bookingList = new List<BookingClass>();
            OracleParameter output = cmd.Parameters.Add("booking_cursor_", OracleDbType.RefCursor);
            output.Direction = ParameterDirection.Output;
            cmd.ExecuteNonQuery();

            OracleDataReader reader = ((OracleRefCursor)output.Value).GetDataReader();
            while (reader.Read())
            {
                BookingClass eve = new BookingClass();

                eve.BookingID = reader.GetInt32(0);
                eve.BookingDate = reader.GetDateTime(1).ToString();
                eve.UserID = reader.GetInt32(2);
                eve.EventID = reader.GetInt32(3);


                bookingList.Add(eve);
            }
            conn.Close();

            DataTable dTabEve = new DataTable();
            dTabEve = CreateBookingTable();

            foreach (BookingClass ev in bookingList)
            {
                dTabEve.Rows.Add(ev.BookingID, ev.BookingDate, ev.UserID,
                    ev.EventID); // 
            }
            return dTabEve;


        }

        #endregion RetrieveBooking

        

        #region InsertBooking
        public void InsertBooking(int eventID)
        {
            string insertProcedure = "Booking_Naddlk_API.Insert_Booking_Naddlk";

            OracleDataAdapter adapter = new OracleDataAdapter(insertProcedure, conn);
            adapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            adapter.SelectCommand.Parameters.Add("event_id", OracleDbType.Int32).Value = eventID;

            try
            {
                conn.Open();
                //OracleTransaction trans = conn.BeginTransaction();
                int exec = adapter.SelectCommand.ExecuteNonQuery();
                //trans.Commit();
                
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("DB Issue");
            }
            finally
            {
                conn.Close();
                System.Windows.Forms.MessageBox.Show("Booking is success", "Success");
            }
        }
        #endregion InsertBooking

        /*
        #region UpdateEvents
        public void UpdateEvents(int eventID, string eventName, string eventDate, string eventTime, string eventCategory, string eventOrganizer, string eventDescription, int ticketPrice)
        {

            DateTime eventDateConv = DateTime.Parse(eventDate, new CultureInfo("en-CA"));
            string updateProcedure = "Event_Naddlk_API.Update_Event_Naddlk";

            OracleDataAdapter adapter = new OracleDataAdapter(updateProcedure, conn);
            adapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            adapter.SelectCommand.Parameters.Add("event_id", OracleDbType.Int32).Value = eventID;
            adapter.SelectCommand.Parameters.Add("event_name", OracleDbType.Varchar2).Value = eventName;
            adapter.SelectCommand.Parameters.Add("event_date", OracleDbType.Date).Value = eventDateConv;
            adapter.SelectCommand.Parameters.Add("event_time", OracleDbType.Varchar2).Value = eventTime;
            adapter.SelectCommand.Parameters.Add("event_category", OracleDbType.Varchar2).Value = eventCategory;
            adapter.SelectCommand.Parameters.Add("event_organizer", OracleDbType.Varchar2).Value = eventOrganizer;
            adapter.SelectCommand.Parameters.Add("event_description", OracleDbType.Varchar2).Value = eventDescription;
            adapter.SelectCommand.Parameters.Add("ticket_price", OracleDbType.Int32).Value = ticketPrice;
            //OracleCommand command = new OracleCommand(updateProcedure, conn);

            try
            {
                conn.Open();
                OracleTransaction trans = conn.BeginTransaction();
                int exec = adapter.SelectCommand.ExecuteNonQuery();
                trans.Commit();
                System.Windows.Forms.MessageBox.Show("Event is Updated", "Sucess");
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("DB update Issue");
            }
            finally
            {
                conn.Close();
            }

        }

        #endregion UpdateEvent
        */

        #region DeleteBook
        public void DeleteBooking(int bookingID)
        {

            string deleteProcedure = "Booking_Naddlk_API.Delete_Booking_Naddlk";
            OracleDataAdapter adapter = new OracleDataAdapter(deleteProcedure, conn);
            adapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            adapter.SelectCommand.Parameters.Add("booking_id", OracleDbType.Int32).Value = bookingID;

            try
            {
                conn.Open();
                //OracleTransaction trans = conn.BeginTransaction();
                int exec = adapter.SelectCommand.ExecuteNonQuery();
                //trans.Commit();
                
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("DB Issue");
            }
            finally
            {
                conn.Close();
                System.Windows.Forms.MessageBox.Show("Booking is Deleted", "Sucess");
            }

        }

        #endregion DeleteBook
        

    }
}
